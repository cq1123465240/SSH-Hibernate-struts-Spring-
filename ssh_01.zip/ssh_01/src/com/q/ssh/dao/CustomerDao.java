package com.q.ssh.dao;

/*
* 客户管理DAO层接口
* */

import com.q.ssh.domain.Customer;

import java.util.List;

public interface CustomerDao {

    void save(Customer customer);

}
