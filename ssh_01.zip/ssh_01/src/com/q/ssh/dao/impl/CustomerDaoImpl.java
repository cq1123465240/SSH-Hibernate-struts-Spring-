package com.q.ssh.dao.impl;

/*
* 客户管理的DAO层实现类
* */

import com.q.ssh.dao.CustomerDao;
import com.q.ssh.domain.Customer;
import org.hibernate.criterion.DetachedCriteria;
import org.springframework.orm.hibernate4.support.HibernateDaoSupport;

public class CustomerDaoImpl extends HibernateDaoSupport implements CustomerDao {

    @Override
    public void save(Customer customer) {
        System.out.println("DAO 中的 save...");
        // 将数据保存到数据库
        System.out.println(customer);
        this.getHibernateTemplate().save(customer);
    }


}
