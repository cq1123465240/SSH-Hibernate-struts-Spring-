package com.q.ssh.web.action;

/*
* 客户管理的 Customer 类
* */

import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;
import com.q.ssh.domain.Customer;
import com.q.ssh.service.CustomerService;

public class CustomerAction extends ActionSupport implements ModelDriven<Customer> {
    // 模型驱动使用对象
    private Customer customer = new Customer();

    @Override
    public Customer getModel() {
        return customer;
    }

    // 注入 CustomerService
    private CustomerService customerService;
    public void setCustomerService(CustomerService customerService) {
        this.customerService = customerService;
    }

    // 保存客户 ：save
    public String save(){
        System.out.println("Action 中的 save...");
        customerService.save(customer);
        return NONE;
    }

}





















































