package com.q.ssh.service;

/*
* 客户管理业务层接口
* */

import com.q.ssh.domain.Customer;

public interface CustomerService {
    void save(Customer customer);
}
