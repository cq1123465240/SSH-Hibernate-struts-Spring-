package com.q.ssh.service.impl;

/*
* 客户管理的业务层实现类
* */

import com.opensymphony.xwork2.ActionContext;
import com.q.ssh.dao.CustomerDao;
import com.q.ssh.domain.Customer;
import com.q.ssh.service.CustomerService;
import org.springframework.transaction.annotation.Transactional;

@Transactional
public class CustomerServiceImpl implements CustomerService {

    // 注入 DAO
    private CustomerDao customerDao;
    public void setCustomerDao(CustomerDao customerDao) {
        this.customerDao = customerDao;
    }

    @Override
    public void save(Customer customer) {
        System.out.println("Service 中的 save...");
        customerDao.save(customer);
    }
}
