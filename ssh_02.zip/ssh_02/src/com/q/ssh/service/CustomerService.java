package com.q.ssh.service;

/*
* 客户管理业务层接口
* */

import com.q.ssh.domain.Customer;

import java.util.List;

public interface CustomerService {
    void save(Customer customer);
    void update(Customer customer);
    void delete(Customer customer);
    Customer findById(Integer id);
    List<Customer> findAllByHQL();
    List<Customer> findAllByQBC();
}
