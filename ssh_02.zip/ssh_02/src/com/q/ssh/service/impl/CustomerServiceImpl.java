package com.q.ssh.service.impl;

/*
* 客户管理的业务层实现类
* */

import com.q.ssh.dao.CustomerDao;
import com.q.ssh.domain.Customer;
import com.q.ssh.service.CustomerService;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Transactional
public class CustomerServiceImpl implements CustomerService {

    // 注入 DAO
    private CustomerDao customerDao;
    public void setCustomerDao(CustomerDao customerDao) {
        this.customerDao = customerDao;
    }

    @Override
    public void save(Customer customer) {
        System.out.println("Service 中的 save...");
        customerDao.save(customer);
    }

    @Override
    public void update(Customer customer) {
        customerDao.update(customer);
    }

    @Override
    public void delete(Customer customer) {
        customerDao.delete(customer);
    }

    @Override
    public Customer findById(Integer id) {
        return customerDao.findById(id);
    }

    @Override
    public List<Customer> findAllByHQL() {
        return customerDao.findAllByHQL();
    }

    @Override
    public List<Customer> findAllByQBC() {
        List<Customer> list = customerDao.findAllByQBC();
        return list;
    }

}
