package com.q.ssh.test;


import com.q.ssh.domain.Customer;
import com.q.ssh.service.CustomerService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;
import java.util.List;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("classpath:applicationContext.xml")
public class SSHDemo1 {

    @Resource(name = "customerService")
    private CustomerService customerService;

    @Test
    // 修改
    public void demo1(){
        Customer customer = customerService.findById(1);
        customer.setName("qwe");
        customerService.update(customer);
    }

    // 删除
    @Test
    public void demo2(){
        Customer customer = customerService.findById(1);
        customerService.delete(customer);
    }

    // 查询所有
    @Test
    public void demo3(){
        List<Customer> list = customerService.findAllByQBC();
        System.out.println(list);
        for(Customer customer : list){
            System.out.println(customer);
        }
    }
}


















